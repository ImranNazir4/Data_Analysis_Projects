class PatientInfo:
    def __init__(self, patient_id):
        self.patient_id = patient_id
