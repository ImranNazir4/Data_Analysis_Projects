#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Created on Mon Feb 21 07:35:37 2022

@author: abeer
"""


from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import text
from sklearn.datasets import load_svmlight_file

from sklearn.feature_extraction.text import TfidfVectorizer

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report

from os import path
import pandas as pd
#import pdb
#from IPython.core.debugger import Tracer
import logging
#import re






class bag(BaseEstimator, TransformerMixin):
    """Takes in dataframe, extracts road name column, outputs average word length"""

    def __init__(self):
        pass

#            

    def transform(self, df, y=None):
        """The workhorse of this feature extractor"""
        t=[tweet for tweet in df['Tweet'] ]
        n=ngram_counter.fit_transform(t)
        print(n)
        return n

    def fit(self, df, y=None):
        """Returns `self` unless something different happens in train and test"""
       # ngram_counter=CountVectorizer(ngram_range=(1, 4), analyzer='char')
        return self

class ItemSelector(BaseEstimator, TransformerMixin):
    def __init__(self, key):
        self.key = key

    def fit(self, x, y=None):
        return self

    def transform(self, data_dict):
        #print(data_dict[self.key])
        for t in data_dict[self.key]:
            #print(t)
            return data_dict[self.key]


def start( training_file,testing_file):      
  
    training_data = pd.read_csv(training_file, sep=',', encoding='latin1', low_memory=False)
    print("training shape" )
    print(training_data.shape)
   
    test_data = pd.read_csv(testing_file,  sep=',', encoding='latin1',low_memory=False)
    print("Testing shape ")
    print(test_data.shape)
    
    
    print("input data ( header of dataset) S")
    print(training_data.columns)
    #-----------training features-----------------------
   
    Y_train = np.asarray([stance for stance in training_data['Label']]) 
    Y_eval = np.asarray([stance for stance in test_data['Label']])
    #[ Optional] : use stop words removal and verify the performance ( any changes ?) 
    #my_stopword_list= text.ENGLISH_STOP_WORDS
    
    # build the feature matrices
 
    
    tweet_word= Pipeline([
                    ('selector', ItemSelector(key='Tweet text')),
                    ('count', CountVectorizer(analyzer='word',binary=False)),
                ])
    tweet_word_tfIdf= Pipeline([
                    ('selector', ItemSelector(key='Tweet text')),
                    ('tfidf', TfidfVectorizer(use_idf=True) ),
                ])
    
    tweet_word_ngram= Pipeline([
                    ('selector', ItemSelector(key='Tweet text')),
                    ('count', CountVectorizer(analyzer='word',binary=True,ngram_range=(1,3))),
                ])
    tweet_char= Pipeline([
                   ('selector', ItemSelector(key='Tweet text')),
                    ('count', CountVectorizer(analyzer='char',binary=True,ngram_range=(2,5))),
                ])
   
    
    # most_frequent or stratified dummy classifier S
    #dummy = DummyClassifier(strategy='stratified') 
    

    ppl = Pipeline([
      
         ('feats', FeatureUnion([
 
    
# ('Tweet',tweet_word),
   #,
  ('tweet_word_tfIdf', tweet_word_tfIdf)
    #,
   
      ]))
 
    
        , ('clf', LogisticRegression(random_state=0, solver='lbfgs'))
      #, ('clf', MultinomialNB())
     
      # ,('clf',dummy)
    ])    
    
        
    
    
    model = ppl.fit(training_data, Y_train)
    model.fit(training_data, Y_train)
#check model parameters
    #print(ppl.get_params)
    
    #Evaluation metrics (per class)
    print(model.classes_)


    y_test = model.predict(test_data)
    print(classification_report(Y_eval, y_test))
   
    
   # save predictions results for further analysis 
    prepare_file_output(y_test,test_data)
    
    
   


def prepare_file_output(y_values,test_df):
    print("prepare predictions output")
   
    
    new_CSV_file="/Users/reemaabuthnain/Downloads/predictions.txt"
    file_new= open(new_CSV_file,'w')
    new_test_df = pd.read_csv(new_CSV_file, sep=',',encoding='latin1',names=['Tweet index', 'Label', 'Tweet text'])
    
    
    index=0    
   
    for y in y_values:
        
        Tweet_ID= test_df.at[index,'Tweet index']
        
        Tweet=test_df.at[index,'Tweet text']
        
        new_test_df.loc[index, 'Tweet index'] = Tweet_ID
        
        new_test_df.loc[index, 'Tweet text'] =Tweet
        new_test_df.loc[index, 'Label'] = str(y)
                   
        index=index+1
        
    
        
    new_test_df.to_csv(new_CSV_file, index=False,sep=',') 
    file_new.close()
    
    
    
    
    
if __name__ == '__main__':
              
   
   Testing_file="/Users/reemaabuthnain/Downloads/test(1).csv"
   training_file="/Users/reemaabuthnain/Downloads/train(1).csv"
   start(training_file,Testing_file)
  
val DF = spark.sparkContext.textFile("/Users/reemaabuthnain/Desktop/NewRain.CSV").map(_.split(",").map(attributes=>Rain(attributes(0),attributes(1).trim.toInt,attributes(2).trim.toDouble,attributes(3).trim.toDouble,attributes(4).trim.toDouble,attributes(5).trim.toInt,attributes(6).trim.toInt,attributes(7).trim.toInt,attributes(8).trim.toDouble,attributes(9).trim.toDouble,attributes(10).trim.toDouble,attributes(11).trim.toInt)).toDF()  
        